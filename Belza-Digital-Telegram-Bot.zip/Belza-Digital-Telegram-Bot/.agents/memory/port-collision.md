---
name: Bot webhook port
description: The runtime constraint for the Belza Digital bot's Flask webhook.
---

The Belza Digital bot and the scaffold API server cannot run together because both bind to port 8080. Keep the bot workflow as the only service on that port when testing or receiving provider webhooks.

**Why:** When the API server occupied port 8080, the bot's Flask server failed to bind, so external webhook requests could not reach the bot even though Telegram polling was still running.

**How to apply:** Stop the scaffold API and mockup workflows before restarting or testing the bot. Verify the bot log shows Flask listening on port 8080.